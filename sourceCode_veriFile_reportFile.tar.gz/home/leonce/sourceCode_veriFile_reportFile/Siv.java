/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package siv;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.security.MessageDigest;
import java.util.*;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author leonce
 */
public class Siv {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        long startTime = System.currentTimeMillis();
        int filesNumber = 0;
        int directoriesNumber = 0;
        //// __________________INITIALIZATION MODE___________________

        if (!(args.length == 1 || args.length == 7 || args.length==9)) {
            System.out.println("Wrong command line arguments..Check help !");
            System.exit(1);
        }
        if (args.length == 9) {
            args[0]="-i";args[1]="-D";args[3]="-V";args[5]="-R";args[7]="-H";
            // validate monitored directory
            File monitorDir = new File(args[2]);
            if (!monitorDir.isDirectory() || !monitorDir.exists()) {
                System.out.println("Error.! First argument should be directory");
                System.exit(1);
            }
            // create verification file object
            File veriFile = new File(args[4]);

            //create report file object
            File reportFile = new File(args[6]);

            // validate hash function passed in command line argument
            if (!("MD5".equalsIgnoreCase(args[8]) || "SHA1".equalsIgnoreCase(args[8]))) {
                System.out.println("Only MD5 or SHA1 are supported");
                System.exit(1);
            }

            // check if verification and report files are outside of monitorDirectory
            if ((monitorDir.equals(veriFile.getParentFile()) || (monitorDir.equals(reportFile.getParentFile())))) {
                System.out.println("Veri.File and Repport File should be outside monitor.Dir");
                System.exit(1);
            }

            //ASK USER ABOUT OVERWRITTING EXISTING FILE by calling the method "userOverwritting"
            Scanner scanner = new Scanner(System.in);
            if (veriFile.exists() || reportFile.exists()) {
                System.out.println("VeriFile or reportFile exists.! Would you like to overwrite it ? Yes or No" + "  ");
                String answer = scanner.nextLine();
                userOverwritting(answer);
            }
            // the below printWriter object (reportDocument) for writing report file        
            PrintWriter reportDocument = new PrintWriter(args[6]);
            // code block below is :retrieving files under monitored directory and store them in a temporary ArrayList "myArrayList"
            //  iterate though myArrayList calculating hashes, then print hashes in verification file
            try ( //the below printwriter object(veriDocument) for writing in verification file
                    PrintWriter veriDocument = new PrintWriter(args[4])) {
                //retrieving files under monitored directory and store them in a temporary ArrayList "myArrayList"
                System.out.println("Computing Hashes..!");
                ArrayList<File> myArrayList = new ArrayList<>(); //Declaration of ArrayList,myArrayList; whic is passed as argument in the function below
                listf(args[2], myArrayList); //Function"listf" to retrieve all files under "args[0]"(monitored dir.)

                try {

                    veriDocument.println("");

                    for (File theFile : myArrayList) {
                        Path file = Paths.get(theFile.toString());
                        PosixFileAttributes attr = Files.readAttributes(file, PosixFileAttributes.class);
                        veriDocument.print(file.toString() + "  ");
                        veriDocument.print(attr.size() + "  ");
                        veriDocument.print(attr.owner() + "  ");
                        veriDocument.print(attr.group() + "  ");
                        veriDocument.print(PosixFilePermissions.toString(attr.permissions()) + "  ");
                        veriDocument.print((attr.lastModifiedTime().toString()) + "  ");
                        byte[] fileBytes = Files.readAllBytes(file);
                        veriDocument.print(getHash(fileBytes, args[8]) + "  " + args[8]);
                        veriDocument.println();
                    }
                    veriFile.setReadOnly();
                    veriDocument.close();
                    filesNumber = myArrayList.size(); // number of parsed files 
                    ////the below code up to "catch", it is for counting parsed directories
                    String[] myArray = new String[myArrayList.size()];
                    for (int i = 0; i < myArrayList.size(); i++) {
                        String parentDirectory = (myArrayList.get(i)).getParent();
                        if (!(Arrays.asList(myArray).contains(parentDirectory))) {
                            myArray[directoriesNumber] = parentDirectory;
                            directoriesNumber++;
                        }
                    }

                } catch (Exception e) {
                }
            }
            /// writting to report file below:

            if (reportFile.exists()) {
                reportDocument.println(" --------REPORT FILE-------");
                reportDocument.println("  ");
                reportDocument.println("Monitored directory        :  " + monitorDir.getPath());
                reportDocument.println("Verification file          :  " + veriFile.getPath());
                reportDocument.println("Number of Directories parsed:  " + directoriesNumber);
                reportDocument.println("Number of files parsed     :  " + filesNumber);
                long endTime = System.currentTimeMillis();
                reportDocument.println("Time taken for initialisation mode:" + (endTime - startTime) + " milliseconds");
                reportDocument.close();

            }
        }
        if (args.length == 7) {
            long startTime2 = System.currentTimeMillis();
            ///_____________ VERIFICATION MODE________________
            args[0]="-v";args[1]="-D";args[3]="-V";args[5]="-R";
            int numberOfWarnings = 0;
            File monitorDir = new File(args[2]);
            if (!monitorDir.isDirectory() || !monitorDir.exists()) {
                System.out.println("Error.! First argument should be directory");
                System.exit(1);
            }
            //a)Declare verification file object;parsing will be done later:
            File veriFile = new File(args[4]);
            //b) and c)verify if verFile and reportFile are outside of monitorDir :
            File reportFile = new File(args[6]);
            if ((monitorDir.equals(veriFile.getParentFile()) || (monitorDir.equals(reportFile.getParentFile())))) {
                System.out.println("Veri.File and Repport File should be outside monitor.Dir");
                System.exit(1);
            }
            // d)i) Check New /Removed files:
            Set<String> monitorSet = new HashSet<>(); // set to contain files found in monitor Dir.
            ArrayList<File> myArrayList = new ArrayList<>(); //Array List to keep temporarily files
            listf(args[2], myArrayList);   //Listf method to put all files in arraylist
            for (File theFile : myArrayList) {
                Path file = Paths.get(theFile.toString());
                monitorSet.add(file.toString());  //adding all elements of arraylist to the set
            }
            Set<String> veriSet = new HashSet<>(); //set to contain files names which were kept in verification file 
            Scanner veriScanner = new Scanner(veriFile); // the scanner to read those names
            while (veriScanner.hasNextLine()) {  // this block is for reading only the first string(file name) of each line
                veriSet.add(veriScanner.next()); //THIS WORKS AS INTENDED IF FILES NAMES DON'T CONTAIN SPACE 
                veriScanner.nextLine();
            }
            veriScanner.close();
            Set<String> newFilesSet = new HashSet<>(monitorSet); //set to contain new files 
            newFilesSet.removeAll(veriSet);   //use set difference method 
            PrintWriter report2 = new PrintWriter(reportFile); // PrintWriter to write the diffrence to the report file
            for (String s : newFilesSet) {  //this block is for writing each string of set difference to the report file 
                report2.println(s + "   (New File)");
                numberOfWarnings++;
            }
            Set<String> removedFilesSet = new HashSet<>(veriSet); //set to contain removed files
            removedFilesSet.removeAll(monitorSet); //use set difference method 
            for (String s : removedFilesSet) { //this block is for writting each string of set difference to the report file
                report2.println(s + "   (Removed File)");
                numberOfWarnings++;
            }

            Scanner veriScanner0 = new Scanner(veriFile); //while block below , allows to retrieve hash function from veriFile
            List<String> firstLineIntoList = new ArrayList<>();
            while (veriScanner0.hasNext()) { //starting from here
                firstLineIntoList.add(veriScanner0.next());
                if (firstLineIntoList.size() == 8) {
                    break;
                }
            }
            veriScanner0.close();// up to here
            Set<String> set1 = new HashSet<>(); // set of all strings which make up veriFile. This set will be cleared When the loop ends up 
            for (String theFiles : monitorSet) { // for each file found in monitred Dir. find out attributes below 
                Path file = Paths.get(theFiles);
                PosixFileAttributes attr = Files.readAttributes(file, PosixFileAttributes.class);
                String theSize = Long.toString(attr.size());
                //ii)
                //The below codes paragraph intends to look file with size different from the one recorded in veriFile before
                Scanner veriScanner2 = new Scanner(veriFile);
                while (veriScanner2.hasNext()) { //this codes block is for searching monitored Dir. files'size in veriFile 
                    set1.add(veriScanner2.next());
                }
                if (!set1.contains(theSize)) {
                    report2.println(file.toString() + " " + theSize + "(Different size than recorded before)"); // thecurrent file name with its size are written in report file 

                    numberOfWarnings++;
                }
                //searching for size ends up here. The size is searched for every file in monitorDir.
                //iii)
                //The below codes paragraph intends to look file with message digest different from the one recorded in veriFile before
                byte[] fileBytes = Files.readAllBytes(file);
                String theDigest = getHash(fileBytes, firstLineIntoList.get(7));
                if (!set1.contains(theDigest)) {
                    report2.println(file.toString() + " " + theDigest + "(Different message digest than recorded before)");
                    numberOfWarnings++;
                }
                // searching for message digest ends up here. The digest is searched for every file in monitorDir.                
                //iv)
                String theUser = attr.owner().toString();
                if (!set1.contains(theUser)) {
                    report2.println(file.toString() + " " + theUser + "(Different owner than recorded before)");
                    numberOfWarnings++;
                }
                //iv)
                String theGroupOwner = attr.group().toString();
                if (!set1.contains(theGroupOwner)) {
                    report2.println(file.toString() + " " + theGroupOwner + "(Different Group than recorded before)");
                    numberOfWarnings++;
                }
                //v)                 
                String theAccess = PosixFilePermissions.toString(attr.permissions());
                if (!set1.contains(theAccess)) {
                    report2.println(file.toString() + " " + theAccess + "(Different access right than recorded before)");
                    numberOfWarnings++;
                }
                //vi)
                String theModifiedTime= attr.lastModifiedTime().toString();
                if (!set1.contains(theModifiedTime)) {
                    report2.println(file.toString() + " " + theModifiedTime + "(Different modification time than recorded before)");
                    numberOfWarnings++;
                }
                set1.clear(); // Clear set for system performance reasons
            }
            filesNumber = myArrayList.size(); // number of parsed files 
            ////the below code up to "catch", it is for counting parsed directories
            String[] myArray = new String[myArrayList.size()];
            for (int i = 0; i < myArrayList.size(); i++) {
                String parentDirectory = (myArrayList.get(i)).getParent();
                if (!(Arrays.asList(myArray).contains(parentDirectory))) {
                    myArray[directoriesNumber] = parentDirectory;
                    directoriesNumber++;
                }
            }
            report2.println();
            report2.println(" --------Summary of findings-------");
            report2.println("  ");
            report2.println("Monitored directory        :  " + monitorDir.getPath());
            report2.println("Verification file          :  " + veriFile.getPath());
            report2.println("Report file          :  " + reportFile.getPath());
            report2.println("Number of Directories parsed:  " + directoriesNumber);
            report2.println("Number of files parsed     :  " + filesNumber);
            report2.println("Number of warnings:  " + numberOfWarnings);
            long endTime2 = System.currentTimeMillis();
            report2.println("Time taken for modification mode:" + (endTime2 - startTime2) + " milliseconds");
            report2.close(); // close file
        }
        else if(args.length==1 ){
            args[0]="-h";
            System.out.println("Initialisation mode: siv -i –D	<monitored_directory> -V <verification_file> -R	<report_file> -H <hash_function>");
            System.out.println("                   : siv iterate through monitored dir.,finding out files attributes and recording them in verification file");
            System.out.println("Verification mode  : siv -v –D <monitored_directory> -V <verification_file> -R <report_file>");
            System.out.println("                   :siv iterate through monitered dir., each file attribute value is compared to the recorded value in verification file ");
            System.out.println(" Supported hash functions: SHA1 and MD5");
            
            
            
        }
    }
    //////////////////////////////////////////////////////////////////////////  METHODS BELOW THIS LINE
    //method to iterate in directory and sub directory retrieving all files

    public static void listf(String directoryName, ArrayList<File> files) {
        File directory = new File(directoryName);
        // get all the files from a directory
        File[] fList = directory.listFiles();
        for (File file : fList) {
            if (file.isFile()) {
                files.add(file);
            } else if (file.isDirectory()) {
                listf(file.getAbsolutePath(), files);
            }
        }
    }

    // Hash function 
    public static String getHash(byte[] inputBytes, String algorithm) {
        String hashValue = "";
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
            messageDigest.update(inputBytes);
            byte[] digestedBytes = messageDigest.digest();
            hashValue = DatatypeConverter.printHexBinary(digestedBytes).toLowerCase();
        } catch (Exception e) {
        }
        return hashValue;
    }

    //Method to ask Overwritting files
    public static void userOverwritting(String userAnswer) {
        boolean yn;
        if (userAnswer.equalsIgnoreCase("yes")) {
            yn = true;
        } else {
            yn = false;
        }
        if (!yn) {
            System.exit(1);
        }
    }

}
